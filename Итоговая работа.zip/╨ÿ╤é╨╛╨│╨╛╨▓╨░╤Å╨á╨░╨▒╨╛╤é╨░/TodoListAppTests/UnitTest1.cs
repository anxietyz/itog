using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TodoListApp;

namespace TodoListAppTests
{
    [TestClass]
    public class TodoListManagerTests
    {
        private TodoListManager manager;

        [TestInitialize]
        public void Setup()
        {
            manager = new TodoListManager();
        }

        [TestMethod]
        public void AddTask_ValidTask_ReturnsSuccessMessage()
        {
            string result = manager.AddTask("Купить продукты");
            Assert.AreEqual("Задача \"Купить продукты\" добавлена.", result);
        }

        [TestMethod]
        public void AddTask_EmptyTask_ReturnsErrorMessage()
        {
            string result = manager.AddTask("");
            Assert.AreEqual("Ошибка: задача не может быть пустой.", result);
        }

        [TestMethod]
        public void RemoveTask_ValidIndex_ReturnsSuccessMessage()
        {
            manager.AddTask("Убраться дома");
            string result = manager.RemoveTask(1);
            Assert.AreEqual("Задача \"Убраться дома\" удалена.", result);
        }

        [TestMethod]
        public void RemoveTask_InvalidIndex_ReturnsErrorMessage()
        {
            string result = manager.RemoveTask(5);
            Assert.AreEqual("Ошибка: некорректный индекс.", result);
        }

        [TestMethod]
        public void ShowTasks_NoTasks_ReturnsEmptyMessage()
        {
            string result = manager.ShowTasks();
            Assert.AreEqual("Список задач пуст.", result);
        }

        [TestMethod]
        public void ShowTasks_WithTasks_ReturnsTaskList()
        {
            manager.AddTask("Сделать домашнее задание");
            manager.AddTask("Позвонить врачу");

            string result = manager.ShowTasks();
            Assert.AreEqual("1. Сделать домашнее задание\n2. Позвонить врачу", result);
        }
    }
}
