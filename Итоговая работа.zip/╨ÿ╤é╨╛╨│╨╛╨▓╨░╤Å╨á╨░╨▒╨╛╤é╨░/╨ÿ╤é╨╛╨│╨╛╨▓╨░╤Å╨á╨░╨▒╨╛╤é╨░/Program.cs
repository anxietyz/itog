﻿using System;
using System.Globalization;

namespace TodoListApp
{
    class Program
    {
        static void Main(string[] args)
        {

            TodoListManager manager = new TodoListManager();

            while (true)
            {
                Console.WriteLine("\n--- Управление списком дел ---");
                Console.WriteLine("1. Добавить задачу");
                Console.WriteLine("2. Удалить задачу");
                Console.WriteLine("3. Показать задачи");
                Console.WriteLine("4. Выйти");

                Console.Write("Введите номер действия: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Введите задачу: ");
                        string addTask = Console.ReadLine();
                        Console.WriteLine(manager.AddTask(addTask));
                        break;
                    case "2":
                        Console.Write("Введите номер задачи для удаления: ");
                        if (int.TryParse(Console.ReadLine(), out int index))
                        {
                            Console.WriteLine(manager.RemoveTask(index));
                        }
                        else
                        {
                            Console.WriteLine("Ошибка: введите корректный номер.");
                        }
                        break;
                    case "3":
                        Console.WriteLine("\nТекущие задачи:");
                        Console.WriteLine(manager.ShowTasks());
                        break;
                    case "4":
                        Console.WriteLine("Выход из программы.");
                        return;
                    default:
                        Console.WriteLine("Ошибка: неверный ввод.");
                        break;
                }
            }
        }
    }
}
