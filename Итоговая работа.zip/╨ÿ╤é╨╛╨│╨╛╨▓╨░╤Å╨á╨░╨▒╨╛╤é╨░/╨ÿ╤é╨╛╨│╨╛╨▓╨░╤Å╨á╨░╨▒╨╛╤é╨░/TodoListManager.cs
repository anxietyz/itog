﻿using System;
using System.Collections.Generic;

namespace TodoListApp
{
    public class TodoListManager
    {
        private List<string> tasks;

        public TodoListManager()
        {
            tasks = new List<string>();
        }

        public string AddTask(string task)
        {
            if (!string.IsNullOrEmpty(task))
            {
                tasks.Add(task);
                return $"Задача \"{task}\" добавлена.";
            }
            return "Ошибка: задача не может быть пустой.";
        }

        public string RemoveTask(int index)
        {
            if (index >= 1 && index <= tasks.Count)
            {
                string removedTask = tasks[index - 1];
                tasks.RemoveAt(index - 1);
                return $"Задача \"{removedTask}\" удалена.";
            }
            return "Ошибка: некорректный индекс.";
        }


        public string ShowTasks()
        {
            if (tasks.Count == 0)
            {
                return "Список задач пуст.";
            }

            string result = "";
            for (int i = 0; i < tasks.Count; i++)
            {
                result += $"{i + 1}. {tasks[i]}\n";
            }
            return result.TrimEnd();
        }
    }
}
